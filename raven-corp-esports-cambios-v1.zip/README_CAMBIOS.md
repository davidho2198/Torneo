# Raven Corp CR — Paquete de Actualización (Esports & Torneos)

Este paquete contiene los archivos nuevos y actualizados listos para copiar dentro de la estructura de tu proyecto (`horizons-export`).

## Archivos incluidos y dónde colocarlos

1. **Base de datos y reglas en PocketBase**
   - `apps/pocketbase/pb_migrations/1795557900_raven_esports_platform.js`: Crea/actualiza campos de roles (`admin`, `organizer`, `player`), aprobación de comunidades (`community_status`), visibilidad de torneos (`show_on_home`, `show_on_tournaments_page`) e inscripciones/historial (`tournament_registrations`).
   - `apps/pocketbase/pb_hooks/community-approval.pb.js`: Impide que un usuario público se registre como `admin` o apruebe su propia comunidad sin permiso de un Administrador.

2. **Rutas y Frontend (`apps/web/src/`)**
   - `apps/web/src/routes.ts`: Registra `/`, `/torneos`, `/login`, `/registro` y `/panel`.
   - `apps/web/src/components/home/arena.tsx`: Diseño oscuro estilo esports vinculado a Raven Corp CR con sección de Próximos Torneos.
   - `apps/web/src/routes/home.tsx`: Conecta la portada con PocketBase para cargar los torneos marcados en inicio.
   - `apps/web/src/routes/tournaments.tsx`: Página completa de torneos con filtro por juego, búsqueda e inscripción de jugadores.
   - `apps/web/src/routes/login.tsx`: Inicio de sesión unificado.
   - `apps/web/src/routes/register.tsx`: Registro inmediato para Jugadores y solicitud pendiente de aprobación para Comunidades.
   - `apps/web/src/routes/dashboard.tsx`: Panel según rol (Admin aprueba comunidades; Comunidad aprobada crea torneos y gestiona inscritos; Jugador revisa inscripciones e historial).

## Pasos rápidos para probarlo en local
1. Copia las carpetas `apps/pocketbase` y `apps/web` de este `.zip` sobre tu carpeta del proyecto (reemplazando `routes.ts`, `home.tsx` y `arena.tsx`).
2. Reinicia PocketBase para que aplique la migración `1795557900_raven_esports_platform.js` y el hook `community-approval.pb.js`.
3. En el panel de PocketBase (`/_/`), asigna `role = "admin"` a tu usuario administrador principal.
4. Levanta el servidor web y prueba registrar un Jugador, solicitar una Comunidad, aprobarla como Admin y publicar un torneo.
